#include<iostream>
#include<string>

#include<sstream>
#include<vector>

using namespace std;

#include "wordlist.h"
/*
struct wordListReturn {
	vector played;
	stringstream currentWord;
}

*/

Hangman::Hangman(string filename = "words.txt"){
	this->filename = filename; //allows specificatioin of new textfile
}

//retrieve function returns a struct containing the
//takes an ifstream object(file) and the integer of the desired word category 
returnStruct Hangman::wordRetrieve(int d) const
{
	//opening file
	file.open(filename);
	//reading from file until desired category
	str strBuffer;           //str buffer holds the words read from the file
	//getting to the correct point in the file (it reads the integer)
	while(strBuffer != d-48)
	{
		getline(f,strBuffer);
	}
	//once at the correct category, it chooses the next word
	//while(strBuffer>d-48 && !f.eof())
	if(strBuffer>d-48 && !f.eof()) 
		getline(f,strBuffer);
		
	else
		cerr<<"I'm out of words, go do something else"<<endl;
	//closing file

	file.close();
	//setting ss equal to current word
	filestruct.currentWord.str(strBuffer);
	//adding word to vector of words played
	//wordsPlayed.push_back(strBuffer);
	
	//adding word to the list of played words in the struct
	filestruct.wordsPlayed.push_back(strBuffer)

	return filestruct;
}

void Hangman::display()const{
	cout<<filestruct.currentWord.rdbuf();
}

