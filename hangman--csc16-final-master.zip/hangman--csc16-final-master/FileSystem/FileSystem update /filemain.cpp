#include "filesyst.h"

using namespace std;

int main(){
	FileSystem f1;
	f1.stackConstructor();
	cout<<f1.wordReturn(1)<<endl;
	cout<<f1.wordReturn(2)<<endl;
	cout<<f1.wordReturn(1)<<endl;
	return 0;
}
 
