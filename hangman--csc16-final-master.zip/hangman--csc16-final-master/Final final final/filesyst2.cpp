#include "filesyst.h"
#include<vector>
#include<cstdlib>

FileSystem::FileSystem(){
	Stack Food; 
	Stack Animals;
	Stack Capitals;
	Stack Names; 
	//stackConstructor();
}


void FileSystem::stackConstructor() 
{
	std::vector<std::string> FoodVector = {"spaghetti","potato","burrito","hamburger","lasagna","watermelon","cookie","yogurt","cheerios","taquitos"};
	std::vector<std::string> AnimalsVector = {"ape","chameleon","bonobo","rat","gorilla","capuchin","platypus","bobcat", "snake","axolotl"};
	std::vector<std::string> CapitalsVector = {"concord","albany","montpellior", "bismark","topeka", "harrisburg", "sacremento", "honolulu", "cheyenne", "olympia"};
	std::vector<std::string> NamesVector = {"camden","edison", "kyle", "chad","phelony", "sam", "zea","vivian", "frankenstein", "wolverine"}; 
	int N = 10;
//first loop get numbers
	for(int i =0;i<N;i++)
	{
		Food.push(FoodVector[i]);
		Animals.push(AnimalsVector[i]);
		Capitals.push(CapitalsVector[i]);
		Names.push(NamesVector[i]);
		}
}


	
std::string FileSystem::wordReturn(int a){
	std::string strBuffer;
        std::string emptyState ("1");
	//std::stringstream returnedWord; 	
	int seed = rand()%10-1;
	if(a==1){
          if(!Food.isempty())
		strBuffer = Food.gorillagrip(seed);
		//returnedWord.str(strBuffer);
          else
             strBuffer = emptyState;
		}
	else if(a==2){
          if(!Animals.isempty())
                strBuffer = Animals.gorillagrip(seed);
                //returnedWord.str(strBuffer)
         else
            strBuffer = emptyState;
                }
	else if(a==3){
          if(!Capitals.isempty())
               strBuffer = Capitals.gorillagrip(seed);
                //returnedWord.str(strBuffer);
          else
             strBuffer = emptyState;
		}
	else if(a==4){
          if(!Names.isempty())
                strBuffer = Names.gorillagrip(seed);
                //returnedWord.str(strBuffer);
         else
             strBuffer = emptyState;
		}
//	std::cout<<"strBuffer: "<<strBuffer<<std::endl;
	return strBuffer;
}


