#include<string>
#include<iostream>

#ifndef STACK_H
#define STACK_H

typedef std::string Datatype;
//default stack size 
const int S=10;

class Stack
{
public:
//      Stack();
        Stack(unsigned int capacity=S);
        bool isempty();
        void push(Datatype d);
//display element on top of stack
        Datatype top();
	Datatype gorillagrip(int a);
//remove element on top of stack 
        Datatype pop(int a);
        void display();
        unsigned int getsize() {return m_size;}
        ~Stack();
private:
//array to hold elements
        Datatype *data_array;
//int to indicate top of stack
        int m_top;
        unsigned int m_size;
        unsigned int m_capacity;
};


#endif  //STACK_H

