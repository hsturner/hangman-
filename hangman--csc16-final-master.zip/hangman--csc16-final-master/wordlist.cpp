#include<iostream>
#include<string>

#include<sstream>
#include<vector>

using namespace std;

/*
struct wordListReturn {
	vector played;
	stringstream currentWord;
}

*/

	
//retrieve function returns a struct containing the 
struct wordRetrieve(std::ifstream &f,int d)
{
	//elements to put inside struct
	vector<string> wordsPlayed;
	stringstream fileWord;
	//opening file
	f.open();
	//reading from file until desired category
	str strBuffer;
	getline(f,strBuffer);
	//getting to the correct point in the file (it reads the integer)
	while(strBuffer != d-48)
	{
		getline(f,strBuffer);
	}
	//once at the correct category, it chooses the next word
	//while(strBuffer>d-48 && !f.eof())
	if(strBuffer>d-48 && !f.eof()) 
		getline(f,strBuffer);
		
	else
		cerr<<"I'm out of words, go do something else"<<endl;
	//closing file

	f.close();
	//setting ss equal to current word
	fileWord.str(strBuffer);
	//adding word to vector of words played
	wordsPlayed.push_back(strBuffer);
	
	struct wordListReturn {
		currentWord = fileWord;
		playedList = wordsPlayed;
	}	

	return wordListReturn;
}

