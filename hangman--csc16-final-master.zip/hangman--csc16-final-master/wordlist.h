#ifndef WORDLIST_H
#define WORDLIST_H


#include<iostream>
#include<string>
#include <vector>


stringstream wordRetrieve(std::ifstream &f,int a, vector b);


#endif //WORLDLIST_H
