#include <iostream>
#include<string>
#include <sstream>
#include<vector>

using namespace std;

#include "wordlist.h"

int main()
{

Hangman h1;
std::cout<<h1.wordRetrieve(2)<<endl;

return 0;
}
 

