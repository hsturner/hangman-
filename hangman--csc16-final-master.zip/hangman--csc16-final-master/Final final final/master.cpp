//FINAL CPP FILE

#include "w_final.h"

int Fill(char guess, string secretword, string &guessword)
{

        int matches = 0;
        int len = secretword.length();

        for (int i = 0; i< len; i++)
        {
                // letter already guessed
                if (guess == guessword[i])
                        return 0;
                // letter IS in the secret word
                if (guess == secretword[i])
                {
                        guessword[i] = guess;
                        matches++;
                }
        }
        return matches;

}

void opening_message()
{
           cout << "\n\nEach letter is represented by a dash (-)";
           cout << "\n\nOnly one letter is accepted per guess";
           cout << "\n\nYou have " << MAX_TRIES << " tries to try and guess the word";
           cout << "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
}


bool correct_word(string checkWord, string unknown, bool break_flag)
{
      if (checkWord == unknown)
      {
        cout <<"\n\n            "<<checkWord <<"\n"<< endl;
        cout << "You have successfully guessed the word!\n";
        break_flag=false;
      }
      else break_flag = true;
      return break_flag;
}
void display(const int MAX_TRIES, int num_of_wrong_guesses)
{
             if (num_of_wrong_guesses == 0) emptyGallows();
             else if (num_of_wrong_guesses == 1) addHeadPicture();
             else if (num_of_wrong_guesses == 2) addBodyPicture();
             else if (num_of_wrong_guesses == 3) addArm1Picture();
             else if (num_of_wrong_guesses == 4) addArm2Picture();
             else addLeg1Picture();
             cout << "You have " << MAX_TRIES - num_of_wrong_guesses<< " guesses left." << endl;
}

bool play_again_loop()
{
                bool valid_answer = false;
                bool keep_playing = true;
                string response;
                while (valid_answer == false)
                {
                  cout<<"Would you like to play again? Yes/No?"<<endl;
                  cin >> response;
                  if ((response == "yes" || response == "YES" || response == "Yes") || (response == "no" || response == "NO" || response == "No"))
                    {
                    valid_answer = true;
                    if (response == "no" || response == "NO" || response == "No")
                    {
                      keep_playing = false;
                      cout<<"Thanks for playing our game! Hope you liked it! Give us a 100, but only if you think it deserves it.\nA 95 would be cool too I guess."<<endl;
                    }
                    }
                  else cout<<"\nPlease enter Yes or No"<<endl;
               }
      return keep_playing;
}



void emptyGallows()
{
   cout<<"   |-------------"<<endl<<"   |             |"<<endl<<
   "   |             |"<<endl<<"   |"<<endl<<
   "   |"<<endl<<"   |"<<endl<<
   "   |"<<endl<<"   |"<<endl<<
   "   |"<<endl<<"   |"<<endl<<
   "   |"<<endl<<"   |   "<<endl<<"---------------------------------------"<<endl;      
}
 
void addHeadPicture()
{
   cout<<"   |-------------"<<endl<<"   |             |"<<endl<<
   "   |             |"<<endl<<"   |             0"<<endl<<
   "   |"<<endl<<"   |"<<endl<<
   "   |"<<endl<<"   |"<<endl<<
   "   |"<<endl<<"   |"<<endl<<
   "   |"<<endl<<"   |   "<<endl<<"---------------------------------------"<<endl;
}

void addBodyPicture()
{
  cout<<"   |-------------"<<endl<<"   |             |"<<endl<<
  "   |             |"<<endl<<"   |             0"<<endl<<
  "   |             |"<<endl<<"   |             |  "<<endl<<
  "   |             |"<<endl<<"   |             |"<<endl<<
  "   |"<<endl<<"   |"<<endl<<
  "   |"<<endl<<"   |   "<<endl<<"---------------------------------------"<<endl;
}

void addArm1Picture()
{
  cout<<"   |-------------"<<endl<<"   |             |"<<endl<<
  "   |             |"<<endl<<"   |             0"<<endl<<
  "   |           --|"<<endl<<"   |           | |"<<endl<<
  "   |           + | "<<endl<<"   |             |"<<endl<<
  "   |"<<endl<<"   |"<<endl<<
  "   |"<<endl<<"   |   "<<endl<<"---------------------------------------"<<endl;
}


void addArm2Picture()
{
  cout<<"   |-------------"<<endl<<"   |             |"<<endl<<
  "   |             |"<<endl<<"   |             0"<<endl<<
  "   |           --|--"<<endl<<"   |           | | |"<<endl<<
  "   |           + | +"<<endl<<"   |             |"<<endl<<
  "   |"<<endl<<"   |"<<endl<<
  "   |"<<endl<<"   |   "<<endl<<"---------------------------------------"<<endl;
}

void addLeg1Picture()
{
  cout<<"   |-------------"<<endl<<"   |             |"<<endl<<
  "   |             |"<<endl<<"   |             0"<<endl<<
  "   |           --|--"<<endl<<"   |           | | |"<<endl<<
  "   |           + | +"<<endl<<"   |             |"<<endl<<
  "   |            /"<<endl<<"   |"<<endl<<
  "   |"<<endl<<"   |   "<<endl<<"---------------------------------------"<<endl;
}

void gameOverScreen()
{
  cout<<"\n   |-------------"<<endl<<"   |             |"<<endl<<
  "   |             |"<<endl<<"   |             0"<<endl<<
  "   |           --|--"<<endl<<"   |           | | |"<<endl<<
  "   |           + | +"<<endl<<"   |             |"<<endl<<
  "   |            / \\"<<endl<<"   |"<<endl<<
  "   |"<<endl<<"   |   "<<endl<<"---------------------------------------"<<endl<<endl<<
  "             GAME OVER"<<endl<<endl;
}

/*
void play_game(string word, char letter, int num_of_wrong_guesses, bool break_flag)
{
                // Initialize the secret word with the - character.
                string unknown(word.length(), '-');
                cout << "\n\nEach letter is represented by a dash (-)";
                cout << "\n\nOnly one letter is accepted per guess";
                cout << "\n\nYou have " << MAX_TRIES << " tries to guess the secret word";
                cout << "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~";
                // Loop until user runs out of guesses
                while (num_of_wrong_guesses < MAX_TRIES and break_flag==true)
                {
                        cout << "\n\n" << unknown;
                        cout << "\n\nGuess a letter: ";
                        cin >> letter;
                        // Fill secret word with letter,
                        // or increment the number of wrong guesses.
                        if (Fill(letter, word, unknown) == 0)
                        {
                                cout<<endl<<"Uh-oh, That was not in your secret word..."<<endl;
                                num_of_wrong_guesses++;
                        }
                        else
                        {
                                cout << endl << "Success! That was in your secret word!!!"<<endl;
                        }
                        // display counter
                        cout << "You have " << MAX_TRIES - num_of_wrong_guesses<<" "<< " guesses left." << endl;

                        //check if word is completed
                        if (word == unknown)
                        {
                                cout << word << endl;
                                cout << "You have successfully guessed the word!";
                                break_flag=false;
                        }
                  }
                if (num_of_wrong_guesses == MAX_TRIES)
                {
                        cout << "\nUh-oh...you've been hanged." << endl;
                        cout << "Your secret word was : " << word << endl;
                }

                cin.ignore();
                cin.get();
}

*/
