#include<string>
#include <iostream>
using namespace std;
#include "stack2.h"


Stack::Stack(unsigned int capacity)
{
        m_capacity= capacity;
        m_size= 0;
        m_top = -1;
        //allocate space 
        data_array= new Datatype[capacity];
}

////////////////////
bool Stack::isempty()
{
        return m_size==0;
}

///////////////////

void Stack::push(Datatype d)
{
        if(m_size==m_capacity)
        {
                cerr<<"PUSH- Out of stack space"<<endl;
        }
        else
        {
                m_top++;
                data_array[m_top]=d;
                m_size++;
        }
}

//////////////////
Datatype Stack::top()
{

        if(isempty())
        //if the stack has no top element 
        {
                cerr<<"TOP- No top value in place"<<endl;
                //throw runtime_error("error, stack is empty");
        }
        else
                //display the element at index "top"
                return data_array[m_top];

}
//other way to handle errors in top function 

//bool Stack::top(Datatype &d)
//{
//      if(isempty())
//              return false;
//      else
//      {
//              d=data_array[top];
//              return true;
//      }
//}

//////////////////
Datatype Stack::pop(int a)
{
	Datatype m_buffer;
         if(isempty())
        //if the stack has no top element 
        {
                cerr<<"POP- No top value in place"<<endl;
        //        throw runtime_error("error, stack is empty");
        }
	m_buffer = data_array[m_top];
        m_top--;
        m_size--;
	
	return m_buffer;
}

///////////////////
Datatype Stack::gorillagrip (int a){
	std::string gripBuffer;
	//gripBuffer is now equal to a word at index[a]
	gripBuffer = data_array[a]; 
	
	//that word now needs to be removed from the stack
	while (a<m_top){
		data_array[a] = data_array[a+1];
		a++;
		}
	m_top --;
	m_size--;


	return gripBuffer;
}


//////////////////

void Stack::display()
{
        if(isempty())
        {
                cerr<<"DISPLAY- Not top value in place"<<endl;
        }

        //else
        for(int i=0;i<m_size;i++)
        {
                cout<<"element "<<i<<" : "<<data_array[i]<<endl;
        }
        cout<<endl;
}

Stack::~Stack()
{
        delete[]data_array;
}

