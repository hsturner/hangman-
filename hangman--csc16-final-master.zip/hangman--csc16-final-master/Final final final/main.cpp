//FINAL DRIVER FILE

#include "w_final.h"
#include <cctype>
#include "filesyst.h"

using namespace std;


int main()
{
      string name;
      char letter;
      string response;
      string word1;
      string word2;
      string word3;
      string word4;
      srand(time(NULL));   // Only need to initialize once 
      cout<<"Welcome to the our final project: Hangman!"<<endl;
      bool keep_playing = true;
      FileSystem f1;
      f1.stackConstructor();
      string word1="word1";
      string word2="word2";
      string word3="word3";
      string word4="word4";
      while (keep_playing == true)
      {
        int num_of_wrong_guesses = 0;
        int guess_counter = 0;
        int guessed_list[26] = {};
        bool break_flag=true;
        cout<<"\nMake a selection from one of the categories you would like to guess from (just enter the number):"<<
        endl<<"1) Food"<<endl
        <<"2) Animals"<<endl
        <<"3) US State Capitals"<<endl
        <<"4) Names"<<endl;

        string cat;
        cin >> cat;
        
        while(!word1.isempty() && !word2.isempty() && !word3.isempty() && word4.isempty())
        {

        // compare level 
        if (cat  == "1")//FOOD CATEGORY
        {
                //array if strings to randomly select 
                string word1 = f1.wordReturn(1);
                // display the secret word with (-)
                string unknown(word1.length(), '-');
                opening_message();
                cout<<"You have picked the food category"<<endl;
                emptyGallows();
                // loop until user runs out of guesses
                while (num_of_wrong_guesses < MAX_TRIES and break_flag==true)
                {
                        cout << "\n\n" <<"              "<< unknown;
                        cout << "\n\nGuess a letter: ";
                        cin >> letter;
                        // Check for repeated letters
                        // Check for repeated letters
                        bool repeat_letter_flag = false;
                        for (int i = 0; i < 26; i++)
                          if (isalpha(letter))
                            if (guessed_list[i] == tolower(letter)) repeat_letter_flag = true;
                        //Error handling for letters and repeats
                        if (isalpha(letter) and repeat_letter_flag == false)
                        {
                          // Convert letter to lowercase 
                          letter = tolower(letter);
                          //Add the letter to the guessed list if it isn't there already
                          guessed_list[guess_counter] = letter;
                          guess_counter ++;
                          // Fill secret word with letter,
                          // or increment the number of wrong guesses.

                          if (Fill(letter, word1, unknown) == 0)
                          {
                                cout<<endl<<"Uh-oh, That was not in your secret word..."<<endl;
                                num_of_wrong_guesses++;
                          }
                          else
                          {
                                cout << endl << "Success! That was in your secret word!!!"<<endl;
                          }
                          // display hangman
                          display(MAX_TRIES, num_of_wrong_guesses);
                          //Display the guessed list
                          cout<<"These are the letters you've guessed: ";
                          for (int i = 0; i < 26; i++)
                          {
                            if (guessed_list[i] == 0) ;
                            else cout<<(char)guessed_list[i]<<" ";
                          }


                          //check if word is completed
                          string checkWord = word1;
                          break_flag = correct_word(checkWord, unknown, break_flag);
                        }
                        // The inputted letter was bad
                        else
                        {
                          if (isalpha(letter)== false) cout<<"\nPlease enter a letter!"<<endl;
                          else cout<<"\nYou've guessed this letter already. Try again!"<<endl;
                          cout << "You have " << MAX_TRIES - num_of_wrong_guesses<< " guesses left." << endl;
                          //Display the guessed list
                          cout<<"These are the letters you've guessed: ";
                          for (int i = 0; i < 26; i++)
                          {
                            if (guessed_list[i] == 0) ;
                            else cout<<(char)guessed_list[i]<<" ";
                          }
                        }
                }
                if (num_of_wrong_guesses == MAX_TRIES)
                {
                        gameOverScreen();
                        cout << "     Your secret word was : " << word1 << endl;
                }
                // Play again loop
                keep_playing = play_again_loop();
        }
        else if (cat == "2") //ANIMALS CATEGORY
        {
                word2 = f1.wordReturn(2);
                // represent the secret word with the - character.
                string unknown(word2.length(), '-');
                opening_message();
                cout<<"You have picked the animal category"<<endl;
                emptyGallows();
                // loop until user runs out of guesses
                while (num_of_wrong_guesses < MAX_TRIES and break_flag==true)
                {
                        cout << "\n\n" <<"              "<< unknown;
                        cout << "\n\nGuess a letter: ";
                        cin >> letter;
                        // Check for repeated letters
                        bool repeat_letter_flag = false;
                        for (int i = 0; i < 26; i++)
                          if (isalpha(letter))
                            if (guessed_list[i] == tolower(letter)) repeat_letter_flag = true;
                        //Error handling for letters and repeats
                        if (isalpha(letter) and repeat_letter_flag == false)
                        {
                          // Convert letter to lowercase
                          letter = tolower(letter);
                          //Add the letter to the guessed list
                          guessed_list[guess_counter] = letter;
                          guess_counter ++;
                          // Fill secret word with letter,
                          // or increment the number of wrong guesses.

      	                  if (Fill(letter, word2, unknown) == 0)
                          {
                                cout<<endl<<"Uh-oh, That was not in your secret word..."<<endl;
                                num_of_wrong_guesses++;
                          }
                          else
                          {
                                cout << endl << "Success! That was in your secret word!!!"<<endl;
                          }
                          // display hangman
                          display(MAX_TRIES, num_of_wrong_guesses);
                          //Display the guessed list
                          cout<<"These are the letters you've guessed: ";
                          for (int i = 0; i < 26; i++)
                          {
                            if (guessed_list[i] == 0) ;
                            else cout<<(char)guessed_list[i]<<" ";
                          }
                          //check if word is completed
                          string checkWord = word2;
                          break_flag = correct_word(checkWord, unknown, break_flag);
                        }
                        // The inputted letter was bad
                        else
                        {
                          if (isalpha(letter)== false) cout<<"\nPlease enter a letter!"<<endl;
                          else cout<<"\nYou've guessed this letter already. Try again!"<<endl;
                          cout << "You have " << MAX_TRIES - num_of_wrong_guesses<< " guesses left." << endl;
                          //Display the guessed list
                          cout<<"These are the letters you've guessed: ";
                          for (int i = 0; i < 26; i++)
                          {
                            if (guessed_list[i] == 0) ;
                            else cout<<(char)guessed_list[i]<<" ";
                          }
                        }
                }
                if (num_of_wrong_guesses == MAX_TRIES)
                {
                        gameOverScreen();
                        cout << "     Your secret word was : " << word2 << endl;
                }
                // Play again loop
                keep_playing = play_again_loop();
        }

         else if (cat == "3") //USA STATE CAPITALS
         {
                word3 = f1.wordReturn(3);
                // Initialize the secret word with the - character.
                string unknown(word3.length(), '-');
                opening_message();
                cout<<"You have picked the state capitals category"<<endl;
                emptyGallows();
                // loop until user runs out of guesses
                while (num_of_wrong_guesses < MAX_TRIES and break_flag==true)
                {
                        cout << "\n\n" <<"              "<< unknown;
                        cout << "\n\nGuess a letter: ";
                        cin >> letter;
                        // Check for repeated letters
                        bool repeat_letter_flag = false;
                        for (int i = 0; i < 26; i++)
                          if (isalpha(letter))
                            if (guessed_list[i] == tolower(letter)) repeat_letter_flag = true;
                        //Error handling for letters and repeats
                        if (isalpha(letter) and repeat_letter_flag == false)
                        {
                          // Convert letter to lowercase
                          letter = tolower(letter);
                          //Add the letter to the guessed list
                          guessed_list[guess_counter] = letter;
                          guess_counter ++;
                          // Fill secret word with letter,
                          // or increment the number of wrong guesses.
                          if (Fill(letter, word3, unknown) == 0)
                          {
                                cout<<endl<<"Uh-oh, That was not in your secret word..."<<endl;
                                num_of_wrong_guesses++;
                          }
                          else
                          {
                                cout << endl << "Success! That was in your secret word!!!"<<endl;
                          }
                          // display hangman
                          display(MAX_TRIES, num_of_wrong_guesses);
                          //Display the guessed list
                          cout<<"These are the letters you've guessed: ";
                          for (int i = 0; i < 26; i++)
                          {
                            if (guessed_list[i] == 0) ;
                            else cout<<(char)guessed_list[i]<<" ";
                          }
                          //check if word is completed
                          string checkWord = word3;
                          break_flag = correct_word(checkWord, unknown, break_flag);
                        }
                        // The inputted letter was bad
                        else
                        {
                          if (isalpha(letter)== false) cout<<"\nPlease enter a letter!"<<endl;
                          else cout<<"\nYou've guessed this letter already. Try again!"<<endl;
                          cout << "You have " << MAX_TRIES - num_of_wrong_guesses<< " guesses left." << endl;
                          //Display the guessed list
                          cout<<"These are the letters you've guessed: ";
                          for (int i = 0; i < 26; i++)
                          {
                            if (guessed_list[i] == 0) ;
                            else cout<<(char)guessed_list[i]<<" ";
                          }
                        }
                }
                if (num_of_wrong_guesses == MAX_TRIES)
                {
                        gameOverScreen();
                        cout << "     Your secret word was : " << word3 << endl;
                }
                // Play again loop
                keep_playing = play_again_loop();
        }

        else if (cat == "4") // NAMES 
        {
                word4 = f1.wordReturn(4);
                // Initialize the secret word with the - character.
                string unknown(word4.length(), '-');
                opening_message();
                cout<<"You have picked the names category"<<endl;
                emptyGallows();
                // loop until user runs out of guesses
                while (num_of_wrong_guesses < MAX_TRIES and break_flag==true)
                {
                        cout << "\n\n" <<"              "<< unknown;
                        cout << "\n\nGuess a letter: ";
                        cin >> letter;
                        // Check for repeated letters
                        bool repeat_letter_flag = false;
                        for (int i = 0; i < 26; i++)
                          if (isalpha(letter))
                            if (guessed_list[i] == tolower(letter)) repeat_letter_flag = true;
                        //Error handling for letters and repeats
                        if (isalpha(letter) and repeat_letter_flag == false)
                        {
                          // Convert letter to lowercase
                          letter = tolower(letter);
                          //Add the letter to the guessed list
                          guessed_list[guess_counter] = letter;
                          guess_counter ++;
                          // Fill secret word with letter,
                          // or increment the number of wrong guesses.
                          if (Fill(letter, word4, unknown) == 0)
                          {
                                cout<<endl<<"Uh-oh, That was not in your secret word..."<<endl;
                                num_of_wrong_guesses++;
                          }
                          else
                          {
                                cout << endl << "Success! That was in your secret word!!!"<<endl;
                          }
                          // display hangman
                          display(MAX_TRIES, num_of_wrong_guesses);
                          //Display the guessed list
                          cout<<"These are the letters you've guessed: ";
                          for (int i = 0; i < 26; i++)
                          {
                            if (guessed_list[i] == 0) ;
                            else cout<<(char)guessed_list[i]<<" ";
                          }
                          //check if word is completed
                          string checkWord = word4;
                          break_flag = correct_word(checkWord, unknown, break_flag);
                        }
                        // The inputted letter was bad
                        else
                        {
                          if (isalpha(letter)== false) cout<<"\nPlease enter a letter!"<<endl;
                          else cout<<"\nYou've guessed this letter already. Try again!"<<endl;
                          cout << "You have " << MAX_TRIES - num_of_wrong_guesses<< " guesses left." << endl;
                          //Display the guessed list
                          cout<<"These are the letters you've guessed: ";
                          for (int i = 0; i < 26; i++)
                          {
                            if (guessed_list[i] == 0) ;
                            else cout<<(char)guessed_list[i]<<" ";
                          }
                        }
                }
                if (num_of_wrong_guesses == MAX_TRIES)
                {
                        gameOverScreen();
                        cout << "     Your secret word was : " << word4 << endl;
                }
                // Play again loop
                keep_playing = play_again_loop();
        }
        // Invalid menu option
        else cout<<"Please enter a valid menu option"<<endl;
      
        } // end of loop empty check 
        cout<<"Empty category, you're outta words bub"<<endl;
        break;
        } //keep playing loop
     cin.ignore();
     cin.get();
     return 0;
}

