
#include "filesyst.h"
#include<vector>
#include<cstdlib>

FileSystem::FileSystem(){
	Stack Food; 
	Stack Animals;
	Stack Capitals;
	Stack Names; 
	//stackConstructor();
}


void FileSystem::stackConstructor() 
{
	
	std::vector<std::string> FoodVector = {"Spaghetti","Potato","Burrito","Hamburger","Lasagna","Watermelon","Cookie","Yoghurt","Cheerios","Tacquitos"};
	std::vector<std::string> AnimalsVector = {"Ape","Chameleon","Bonobo","Rat","Gorilla","Capuchin","Platypus","Bobcat", "Snake","Axolotl"};
	std::vector<std::string> CapitalsVector = {"Concord","Albany","Montpellior", "Bismark","Topeka", "Harrisburg", "Sacremento", "Honolulu", "Cheyenne", "Olympia"};
	std::vector<std::string> NamesVector = {"Camden","Edison", "Kyle", "Chad","Phelony", "Sam", "Zea","Vivian", "Frankenstein", "Wolverine"}; 
	int N = 10;
//first loop get numbers
	for(int i =0;i<N;i++)
	{
		Food.push(FoodVector[i]);
		Animals.push(AnimalsVector[i]);
		Capitals.push(CapitalsVector[i]);
		Names.push(NamesVector[i]);
		}
}

	
std::string FileSystem::wordReturn(int a){
	std::string strBuffer;
	//std::stringstream returnedWord; 	
	int seed = rand()%10-1;
	if(a==1){
		strBuffer = Food.gorillagrip(seed);
		//returnedWord.str(strBuffer);
		}
	else if(a==2){
                strBuffer = Animals.gorillagrip(seed);
                //returnedWord.str(strBuffer)
		}
	else if(a==3){
                strBuffer = Capitals.gorillagrip(seed);
                //returnedWord.str(strBuffer);
		}
	else if(a==4){
                strBuffer = Names.gorillagrip(seed);
                //returnedWord.str(strBuffer);
		}
	std::cout<<"strBuffer: "<<strBuffer<<std::endl;
	return strBuffer;
}

