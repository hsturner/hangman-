#ifndef WORDLIST_H
#define WORDLIST_H

#include<fstream>
#include<iostream>
#include<string>
#include <vector>
#include <sstream>


struct returnStruct{
	std::stringstream currentWord;
	std::vector<std::string>wordsPlayed;
}; 

class Hangman{
	public:
		Hangman(std::string filename = "words.txt");
		returnStruct wordRetrieve(int d) const;
		void display()const;
		
	private:
		returnStruct filestruct;
		std::ifstream file; 
		std::string filename;

};



#endif //WORLDLIST_H

