#include "stack2.h"  
#include<sstream>

#ifndef FILESYST_H
#define FILESYST_H

class FileSystem{
	public:
		FileSystem(); //default constructor
		std::string wordReturn(int a); //funciton to get words
		void stackConstructor(); //makes the stacks
	private:
		Stack Food;
		Stack Animals;
		Stack Capitals; 
		Stack Names;
};


#endif //FILESYST_H

