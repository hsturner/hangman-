
//FINAL H FILE

#ifndef W_FINAL_H
#define W_FINAL_H

#include <iostream>
#include <cstdlib>
#include <ctime>
#include <string>

using namespace std;

//string word;

int Fill(char guess, string secretword, string &guessword);
const int MAX_TRIES= 6;
bool play_again_loop();
void display(const int MAX_TRIES, int num_of_wrong_guesses);
void opening_message();
bool correct_word(string checkWord, string unknown, bool break_flag);
void emptyGallows();
void addHeadPicture();
void addBodyPicture();
void addArm1Picture();
void addArm2Picture();
void addLeg1Picture();
void gameOverScreen();






#endif //w_final.h

